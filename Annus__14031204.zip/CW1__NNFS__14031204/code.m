data=importdata('breast.txt');
list=[80,160,240,320,400,480,560,640];
inputData=data(:,2:10);
outputData=data(:,11);
j=5;
list(j)
inputtraindatafirst=inputData(1:list(j)/2,:);
inputtraindatalast=inputData(size(inputData)-list(j)/2+1:size(inputData),:);
targetdatafirst=outputData(1:list(j)/2,:);
targetdatalast=outputData(size(outputData)-list(j)/2+1:size(outputData),:);
testinputData=inputData(list(j)/2+1:size(inputData)-list(j)/2,:);
testoutputData=outputData(list(j)/2+1:size(outputData)-list(j)/2,:);
concattraininput=cat(1,inputtraindatafirst,inputtraindatalast);
concattrainoutput=cat(1,targetdatafirst,targetdatalast);
net = newff(concattraininput',concattrainoutput',40, {'tansig' 'logsig'}, 'trainr', 'learngd', 'mse');
net.trainParam.goal = 0.03;
net.trainParam.epochs = 1000;
net = train(net, concattraininput',concattrainoutput');
outputOftestinputData=net(testinputData');
transpose_outputOftestinputData=outputOftestinputData';
counter=0;
for i=1:size(transpose_outputOftestinputData)
if (transpose_outputOftestinputData(i)<=0)
transpose_outputOftestinputData(i)=-1;
else
transpose_outputOftestinputData(i)=1;
end
if(transpose_outputOftestinputData(i)== testoutputData(i))
counter=counter+1;
end
end
percentage=(counter/size(testoutputData,1))*100;